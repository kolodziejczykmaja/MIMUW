package tablice;;

public class NieprawidlowaOperacjaException extends RuntimeException {
    public NieprawidlowaOperacjaException(String message) {
        super(message);
    }
}
