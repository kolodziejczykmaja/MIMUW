package tablice;

public class NiezgodneWymiaryException extends Exception {
    public NiezgodneWymiaryException(String message) {
        super(message);
    }
}